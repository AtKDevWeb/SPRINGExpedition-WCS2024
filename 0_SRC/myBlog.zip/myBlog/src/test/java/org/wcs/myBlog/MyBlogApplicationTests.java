package org.wcs.myBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
